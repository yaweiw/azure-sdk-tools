/**
* Copyright (c) Microsoft.  All rights reserved.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

'use strict';
var azure = require('azure');
var prompt = require('prompt');
var program = require('commander');
var util = require('util');

var adauth = require('./lib/adauth');

var baseUri = 'https://management.core.windows.net';

function ensureCredentials(username, password, callback) {
  prompt.override = {
    username: username,
    password: password
  };

  var schema = {
    properties: {
      username: { required: true, message: 'User name: ' },
      password: { hidden: true, required: true, message: 'Password: ' }
    }
  };

  prompt.message = '';
  prompt.delimiter = '';

  prompt.start();

  prompt.get(schema, function (err, result) {
    if (err) {
      callback(err);
    } else {
      callback(null, result.username, result.password);
    }
  });
}

function withCredentials(subscription, callback) {
  ensureCredentials(program.user, program.password, function (err, user, password) {
    if (err) { return callback(err); }

    var tenantId = program.tenant || "common";
    adauth.getCredential(program.authority, tenantId, user, password, subscription, function (err, credential) {
      if (err) { return callback(err); }
      callback(null, credential);
    });
  });
}


function tenantFromUser(username) {
  var match = username.match(/@(.*)+$/);
  if (match === null) {
    throw new Error(util.format('No tenant found in username %s', username));
  }

  var tenant = match[1];
  if (tenant.indexOf('.') === -1) {
    //tenant = tenant + '.onmicrosoft.com';
  }
  return tenant;
}

function fail(err) {
  console.log('FAILED: ', err, err.stack);
}

function logFilter(request, next, callback) {
  console.log('Request: ', util.inspect(request));
  return next(request, function (err, response, body) {
    if (err) {
      console.log('Request failed, err = ', util.inspect(err));
    }
    console.log('Response: ', util.inspect({
      statusCode: response.statusCode,
      headers: response.headers,
      body: response.body,
    }));

    callback(err, response, body);
  });
}

function resultTable(fields, data) {
  var t = new Table({
    head: fields.map(function (f) { return f[1]; })
  });

  data.forEach(function (row) {
    t.push(fields.map(function (f) { return row[f[0]]; }));
  });

  return t.toString();
}

program
  .version('0.0.1')
  .option('-u --user [username]', 'Active directory user name')
  .option('-p --password [password]', 'user password')
  .option('-a --authority <authorityUrl>', 'Active directory authority endpoint');

program
  .command('token')
  .description('get an AD access token')
  .option('-t --tenant <tenantId>', 'Active Directory tenant id')
  .action(function (options) {
    ensureCredentials(program.user, program.password, function (err, user, password) {
      var tenantId = options.tenant || "common";
      adauth.acquireToken(program.authority, tenantId, user, password, function (err, token, response) {
        if (err) {
          console.log('ERROR:', err);
        } else {
          console.log(token);
        }
      })
    })
  });



program.parse(process.argv);
